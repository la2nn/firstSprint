//
//  ProtocolViewController.swift
//  Tasks
//
//  Created by Дарья Витер on 25/10/2019.
//  Copyright © 2019 Viter. All rights reserved.
//

import UIKit

class ProtocolViewController: UIViewController {
	
	@IBOutlet weak var newElement: UITextField!
	@IBOutlet weak var numberOfElement: UITextField!
	@IBOutlet weak var elementByNumber: UILabel!
	
	
	@IBOutlet weak var countOfElements: UILabel!
	@IBOutlet weak var listOfElements: UILabel!
	
	
	@IBAction func addElement(_ sender: UIButton) {
		
	}
	
	@IBAction func printElement(_ sender: UIButton) {
		
	}
	
	@IBAction func printCounfOfElements(_ sender: UIButton) {
		
	}
	
	@IBAction func printListOfElements(_ sender: UIButton) {
		
	}
	
}
